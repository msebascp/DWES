<?php
    interface iToJson {
        public function toJson();
    }
?>